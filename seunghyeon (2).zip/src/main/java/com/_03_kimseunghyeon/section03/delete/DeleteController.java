package com._03_kimseunghyeon.section03.delete;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import static com._03_kimseunghyeon.common.JDBCTemplate.close;
import static com._03_kimseunghyeon.common.JDBCTemplate.getConnection;

public class DeleteController {

    public int deleteMenu(int menuCode) {

        Connection con = getConnection();

        PreparedStatement pstmt = null;
        int result = 0;

        Properties prop = new Properties();

        try {
            prop.loadFromXML(new FileInputStream("src/main/java/com/ohgiraffers/mapper/menu-query.xml"));
            String query = prop.getProperty("deleteMenu");

            pstmt = con.prepareStatement(query);
            pstmt.setInt(1, menuCode);

            result = pstmt.executeUpdate();

        } catch (IOException | SQLException e) {
            e.printStackTrace();

        } finally {
            close(pstmt);
            close(con);
        }

        return result;

    }

}
