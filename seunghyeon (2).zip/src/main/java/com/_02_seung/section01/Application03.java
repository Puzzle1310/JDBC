package com._02_seung.section01;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import static com._02_seung.common.JDBCTemplate.close;
import static com._02_seung.common.JDBCTemplate.getConnection;

public class Application03 {

    public static void main(String[] args) {

        Connection con = getConnection();


        Statement stmt = null;


        ResultSet rset = null;

        try {
            stmt = con.createStatement();
            Scanner sc = new Scanner(System.in);
            System.out.print("조회하려는 사번을 입력해주세요 : ");
            String empId = sc.nextLine();
            String query = "SELECT EMP_ID, EMP_NAME FROM EMPLOYEE WHERE EMP_ID = '" + empId + "'";
            rset = ((java.sql.Statement) stmt).executeQuery(query);
            if(rset.next()) {
                System.out.println(rset.getString("EMP_ID") + ", " + rset.getString("EMP_NAME"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(rset);
            close((Connection) stmt);
            close(con);
        }

    }

}


