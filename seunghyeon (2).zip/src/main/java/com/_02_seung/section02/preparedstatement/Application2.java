package com._02_seung.section02.preparedstatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static com._02_seung.common.JDBCTemplate.close;
import static com._02_seung.common.JDBCTemplate.getConnection;

public class Application2 {

    public static void main(String[] args) {

        Connection con = getConnection();

        PreparedStatement pstmt = null;
        ResultSet rset = null;

        String menuCode = "10";

        try {
            /* ? : placeholder */
            pstmt = con.prepareStatement("SELECT menu_name, menu_price FROM tbl_menu WHERE menu_code = ?");
            pstmt.setString(1, menuCode);

            rset = pstmt.executeQuery();

            if(rset.next()) {
                System.out.println(rset.getString("menu_name") + "은(는) "
                                    + rset.getString("menu_price") + "원");
            }

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            close(rset);
            close(pstmt);
            close(con);
        }

    }

}
