package com._02_seung.section02.preparedstatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static com._02_seung.common.JDBCTemplate.close;
import static com._02_seung.common.JDBCTemplate.getConnection;

public class Application1 {
    public static void main(String[] args) {
        Connection con = getConnection();

        PreparedStatement pstmt = null;
        ResultSet rset = null;
        try {
            pstmt = con.prepareStatement("SELECT emp_id, emp_name FROM employee");

            rset = pstmt.executeQuery();

            while(rset.next()) {
                System.out.println(rset.getString("emp_id") + "번 "
                        + rset.getString("emp_name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            close(rset);
            close(pstmt);
            close(con);
        }

    }

}
