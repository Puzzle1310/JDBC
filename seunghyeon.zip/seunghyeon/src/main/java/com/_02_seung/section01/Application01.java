package com._02_seung.section01;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static com._01_seunghyeon.section02.template.jdbcTemplate.close;
import static com._02_seung.common.JDBCTemplate.getConnection;

public class Application01 {

    public static void main(String[] args) {

        Connection con = getConnection();

        Statement stmt = null;

        ResultSet rset = null;

        try {

            stmt = con.createStatement();
            rset = stmt.executeQuery("SELECT menu_name, menu_price FROM tbl_menu");
            while(rset.next()) {
                System.out.println(rset.getString("menu_name") + "("
                        + rset.getString("menu_price") + "원)");
            }

        } catch (SQLException e) {
            e.printStackTrace();

        } finally {
            close((Connection) rset);
            close((Connection) stmt);
            close(con);
        }

    }

}
