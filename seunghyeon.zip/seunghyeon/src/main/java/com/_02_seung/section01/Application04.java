package com._02_seung.section01;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static com._02_seung.common.JDBCTemplate.close;
import static com._02_seung.common.JDBCTemplate.getConnection;

public class Application04 {
    public class Application4 {

        public static <EmployeeDTO> void main(String[] args) {
            /* [ 직원의 직원번호를 입력받아 해당 직원의 모든 정보를 DTO 객체에 담아 출력하기 ] */

            /* 1. Connection 생성 */
            Connection con = getConnection();

            /* 2. Statement 선언 */
            Statement stmt = null;

            /* 3. ResultSet 선언 */
            ResultSet rset = null;

            EmployeeDTO selectedEmp = null;

            /* 4. 조회할 직원의 직원번호 입력 받기 */
            Scanner sc = new Scanner(System.in);
            System.out.print("조회하실 사번을 입력해주세요 : ");
            String empId = sc.nextLine();

            /* 5. 쿼리문 작성 */
            String query = "SELECT * FROM EMPLOYEE WHERE EMP_ID = '" + empId + "'";

            try {

                /* 6. Statement 인스턴스 생성 */
                stmt = con.createStatement();

                /* 7. ResultSet으로 결과를 반환 받음 */
                rset = stmt.executeQuery(query);

                /* 8. ResultSet에 담긴 결과물을 컬럼명을 이용해 꺼내어 DTO 객체에 set */
                if(rset.next()) {
                    selectedEmp = new EmployeeDTO();

                    selectedEmp.setEmpId(rset.getString("EMP_ID"));
                    selectedEmp.setEmpName(rset.getString("EMP_NAME"));
                    selectedEmp.setEmpNo(rset.getString("EMP_NO"));
                    selectedEmp.setEmail(rset.getString("EMAIL"));
                    selectedEmp.setPhone(rset.getString("PHONE"));
                    selectedEmp.setDeptCode(rset.getString("DEPT_CODE"));
                    selectedEmp.setJobCode(rset.getString("JOB_CODE"));
                    selectedEmp.setSalLevel(rset.getString("SAL_LEVEL"));
                    selectedEmp.setSalary(rset.getInt("SALARY"));
                    selectedEmp.setBonus(rset.getDouble("BONUS"));
                    selectedEmp.setManagerId(rset.getString("MANAGER_ID"));
                    selectedEmp.setHireDate(rset.getDate("HIRE_DATE"));
                    selectedEmp.setEntDate(rset.getDate("ENT_DATE"));
                    selectedEmp.setEntYn(rset.getString("ENT_YN"));
                }

            } catch (SQLException e) {
                e.printStackTrace();

            } finally {
                /* 9. 자원 반납 */
                close(rset);
                close(stmt);
                close(con);
            }

            /* 10. DTO 객체를 활용하여 조회한 결과 내용 출력 */
            System.out.println("selectedEmp : " + selectedEmp);

        }

    }

}
