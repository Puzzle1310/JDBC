package com._01_seunghyeon.section01.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Application01 {

    public static void main(String[] args) {
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            con = DriverManager.getConnection("jdbc:mysql://localhost/bookdto",
                    "seunghyeon", "seunghyeon");
            System.out.println("con :" + con);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    /* 자원은 반드시 반납해야 하므로 close() 메소드로 자원 반납 */
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }}


